import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitor-navigation',
  templateUrl: './visitor-navigation.component.html',
  styleUrls: ['./visitor-navigation.component.css']
})

export class VisitorNavigationComponent implements OnInit {

  // toggleParam=false;

  // hideflag: boolean = false;


  constructor() { 

  }
  
  ngOnInit() {

   }

//   togglePopup = function (status) {
// console.log(this);
// document.getElementById("popupDiv").style.display='block';
// console.log(document.getElementById("popupDiv").style.display);
//     // if (status = true) {
//     //   this.hideflag = false;
//     // }
//     // else {
//     //   this.hideflag = true;
//     // }
//   }
}