import { Component, OnInit } from '@angular/core';
// import { DataService } from '../../Services/data.service';


@Component({
  selector: 'app-visitor-form',
  templateUrl: './visitor-form.component.html',
  styleUrls: ['./visitor-form.component.css'],
})

export class VisitorFormComponent implements OnInit {

  itemVisitorReceived: string[] = [''];
  visitorOther: boolean = false;
  data: any;

  // constructor(private dataService: DataService) {

  // }
    constructor(){

    }
  /**
   * Below would be called when Visitor Type Dropdown is changed. 
   * The "other" parameter would be used to on/off visibility of Other Text box.
   */
  visitorTypes(obj) {

    console.log(obj.value);
    this.visitorOther = (obj.value == 'visitorOther');
  }

  // getItemServiceClass(){
  //     this.itemVisitorReceived = this.dataServiceService.getItems();
  //    }
  loadTheForm(frm) {
    console.log(frm.value);
  }

  submitForm(frm) {
    console.log(frm.value);
  }

 
  ngOnInit() {
 // this.showConfig();
  }

  // showConfig() {
  //   this.dataService.getConfig().subscribe(result => this.data = result); 
  // }
}
