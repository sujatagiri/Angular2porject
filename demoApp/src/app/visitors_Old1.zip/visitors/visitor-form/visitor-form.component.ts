import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitor-form',
  templateUrl: './visitor-form.component.html',
  styleUrls: ['./visitor-form.component.css']
})
export class VisitorFormComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
