import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { RegularVisitorComponent } from './regular-visitor.component';

describe('RegularVisitorComponent', () => {
  let component: RegularVisitorComponent;
  let fixture: ComponentFixture<RegularVisitorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ RegularVisitorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(RegularVisitorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
