import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-regular-visitor',
  templateUrl: './regular-visitor.component.html',
  styleUrls: ['./regular-visitor.component.css']
})
export class RegularVisitorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
