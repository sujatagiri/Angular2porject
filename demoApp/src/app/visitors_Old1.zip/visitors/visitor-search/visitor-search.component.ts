import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitor-search',
  templateUrl: './visitor-search.component.html',
  styleUrls: ['./visitor-search.component.css']
})
export class VisitorSearchComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
