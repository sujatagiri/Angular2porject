import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-pre-registered-visitor',
  templateUrl: './pre-registered-visitor.component.html',
  styleUrls: ['./pre-registered-visitor.component.css']
})
export class PreRegisteredVisitorComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
