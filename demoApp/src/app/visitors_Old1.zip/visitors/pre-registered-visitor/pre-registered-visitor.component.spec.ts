import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PreRegisteredVisitorComponent } from './pre-registered-visitor.component';

describe('PreRegisteredVisitorComponent', () => {
  let component: PreRegisteredVisitorComponent;
  let fixture: ComponentFixture<PreRegisteredVisitorComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PreRegisteredVisitorComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PreRegisteredVisitorComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
