import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitor-navigation',
  templateUrl: './visitor-navigation.component.html',
  styleUrls: ['./visitor-navigation.component.css']
})
export class VisitorNavigationComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
