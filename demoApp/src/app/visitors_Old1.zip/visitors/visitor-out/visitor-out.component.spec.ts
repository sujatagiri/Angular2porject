import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { VisitorOutComponent } from './visitor-out.component';

describe('VisitorOutComponent', () => {
  let component: VisitorOutComponent;
  let fixture: ComponentFixture<VisitorOutComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ VisitorOutComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(VisitorOutComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
