import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-visitor-out',
  templateUrl: './visitor-out.component.html',
  styleUrls: ['./visitor-out.component.css']
})
export class VisitorOutComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
